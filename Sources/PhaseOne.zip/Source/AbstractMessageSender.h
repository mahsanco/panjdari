#pragma once

#ifndef GW_ABSTRACT_MESSAGE_SENDER_H_
#define GW_ABSTRACT_MESSAGE_SENDER_H_

#include <string>

#include "AbstractMessenger.h"

namespace gw
{

/// Interface of message sender
class AbstractMessageSender : public AbstractMessenger
{
public:
	using AbstractMessenger::AbstractMessenger;

	/**
	 * Sends a message to all listening receivers in a group
	 * 
	 * @param message Body of message to send
	 *
	 * @return @c true if sent and @c false otherwise
	 */
	virtual bool send(const std::string& message) noexcept = 0;
};

}

#endif