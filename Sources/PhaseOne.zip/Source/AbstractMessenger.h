#pragma once
#ifndef GW_ABSTRACT_MESSENGER_H_
#define GW_ABSTRACT_MESSENGER_H_

#include <string>

namespace gw
{

/// Interface for a group conversation member (sender or receiver)
class AbstractMessenger
{
public:

	/**
	 *
	 * @param group_address IP Address of messengers' group
	 * @param interface_name Name of network interface that will be used to sent/receive messages
	 * @param port Port number of messengers' group
	 */
	AbstractMessenger(const std::string& group_address, const std::string& interface_name, uint16_t port_number);

protected:
	const std::string& group_address;
	const std::string& interface_name;
	const uint16_t port_number;
};

}

#endif
