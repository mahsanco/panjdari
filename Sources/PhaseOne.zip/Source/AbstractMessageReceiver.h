#pragma once

#ifndef GW_ABSTRACT_MESSAGE_RECEIVER_H_
#define GW_ABSTRACT_MESSAGE_RECEIVER_H_

#include "AbstractMessenger.h"
#include "MutableBuffer.h"

namespace gw
{

/// Interface of message receiver
class AbstractMessageReceiver : public AbstractMessenger
{
public:
	using AbstractMessenger::AbstractMessenger;

	typedef class MutableBuffer MutableBuffer;

	/**
	 * Receives a message.
	 *
	 * @param buffer Reference to @class MutableBuffer. Function will fill it with arrived message.
	 *
	 * @return First a boolean, @c true if receiving is done successfully, @c false otherwise.
	 * 		Second size of the arrived message.
	 *
	 */
	virtual std::pair<bool, std::size_t> receive(MutableBuffer& buffer) noexcept = 0;
};

}  // namespace gw

#endif
