#pragma once

#ifndef GW_LINUX_NATIVE_MULTICAST_BASIC_H_
#define GW_LINUX_NATIVE_MULTICAST_BASIC_H_

#include <string>

namespace gw
{

/**
 * Multicast Basic provides basic requirements such as constructing socket and error handling, which will be used in
 * multicast sender and multicast receiver both.
 */
class LinuxNativeMulticastBasic
{
public:
	/**
	 * Finds primary IPv4 address of the specified interface.
	 *
	 * @param interface_name Name of the specified interface
	 *
	 * @return The found IP address
	 *
	 * @throw system_error If "ioctl()", "socket()" or "close()" face a problem
	 */
	static std::string find_interface_ip(const std::string& interface_name);

	/**
	 * @param interface_name Name of used interface in transmitting messages
	 * @param interface_address Address of corresponding interface name
	 * @param port Port number used to transmit messages
	 * @param multicast_address Multicast IP address used to transmit messages
	 *
	 * @throw system_error @see initialize()
	 */
	LinuxNativeMulticastBasic(const std::string& interface_name, const std::string& interface_address, uint16_t port,
	               const std::string& multicast_address);

	/// Destructor which calls cleanup.
	virtual ~LinuxNativeMulticastBasic() noexcept;

	/**
	 * This function will write socket primary attributes on standard output. Attributes includes interface name,
	 * interface address, port number and multicast address.
	 *
	 * A sample of output:
	 *
	 * Interface Name: eth0
	 * Interface Address: 192.168.100.100
	 * Port: 12345
	 * Multicast Address: 235.127.0.1
	 */
	void print_attributes() const noexcept;

	/// @return Multicast address which is address of group
	const std::string& get_multicast_address() const noexcept;

	/// @Return the code of last error of system
	int get_error_code() const noexcept;

	/// @return Error message of last unsuccessful operation
	std::string get_error_message() const;

	/**
	 * Gets the MTU (Maximum Transfer Unit) size of interface
	 *
	 * @return Value of MTU
	 *
	 * @throw system_error if MTU value could not be got
	 * @throw invalid_argument if length of interface is greater than 'IF_NAMESIZE'
	 */
	size_t get_mtu() const;

	/**
	 * Sets the MTU (Maximum Transfer Unit) size of interface
	 *
	 * @throw invalid_argument If value is less than 68
	 * @throw system_error If MTU value could not be set
	 */
	void set_mtu(size_t value) const;

	/// @return file descriptor of the socket
	int get_socket_descriptor() const noexcept;

	/// @return IP address of the interface
	std::string get_interface_address() const noexcept;

protected:
	/**
	 * Initializes the object and makes it ready to transmit messages. This function must be called before using others.
	 *
	 * @throw system_error If socket could not be created or configured
	 */
	void initialize();

	/**
	 * Creates udp socket.
	 *
	 * @throw system_error If socket could not be created
	 */
	void create_udp_socket();

	/**
	 * Allows the socket address to be reused.
	 *
	 * @throw system_error If socket could not be reusable
	 */
	void make_reusable();

	/**
	 * Binds socket to an specified interface and port.
	 *
	 * @throw system_error If socket could not be bound
	 */
	virtual void socket_bind() = 0;

	/**
	 * Releases allocated resources, should be called before destructing or in it.
	 *
	 * Note that this function must not throw exception, because it is called in destructor by default.
	 */
	virtual void cleanup() noexcept;

	/// Created socket to send or receive messages
	int socket_descriptor;

private:
	/// Name of used interface
	const std::string interface_name;

public:
	/// IP address of used interface
	const std::string interface_address;

	/// Bound port of the socket
	const uint16_t port;

	/// IP address of multicast group to transmit messages
	const std::string multicast_address;

	/// Error code of last internal used system call
	int system_error_code;
};

}  // namespace gw

#endif
