#pragma once

#ifndef GW_LINUX_NATIVE_MESSAGE_SENDER_H_
#define GW_LINUX_NATIVE_MESSAGE_SENDER_H_

#include <string>

#include <netinet/in.h>


#include "LinuxNativeMulticastBasic.h"
#include "../AbstractMessageSender.h"

namespace gw
{

/**
 * An interface to send byte array messages to given multicast address on specified interface. It uses IPv4 multicast
 * implementation and sends UDP packets.
 */
class LinuxNativeMessageSender : public AbstractMessageSender, public LinuxNativeMulticastBasic
{
public:
	/**
	 * @see LinuxNativeMulticastBasic::LinuxNativeMulticastBasic()
	 *
	 * @param should_send_to_loopback Specifies if the messages should be sent to loop-back or not
	 *
	 * @throw system_error @see LinuxNativeMulticastBasic::initialize()
	 */
	LinuxNativeMessageSender(const std::string& group_address, const std::string& interface_name,
	                           uint16_t port_number, bool should_send_to_loopback = true);

	/// @see LinuxNativeMulticastBasic::LinuxNativeMulticastBasic()
	~LinuxNativeMessageSender() = default;

	/**
	 * Sends message with given size to specified multicast address.
	 *
	 * @param message Pointer to message that will be sent
	 * @param message_size Size of to be sent message
	 *
	 * @return @c true if the message is sent successfully, @c false otherwise
	 *
	 * @note If send method returns false, occurred error message could be determined by calling 'get_error_message()'
	 */
	bool send(const uint8_t* message, size_t message_size) noexcept;
	bool send(const std::string& message) noexcept override;

private:
	/// @see LinuxNativeMulticastBasic::initialize()
	void initialize();

	/// @see LinuxNativeMulticastBasic::socket_bind()
	void socket_bind() override;

	/**
	 * Binds socket to given interface specified by its name.
	 *
	 * @throw system_error If the socket could not be bound to interface
	 */	
	void bind_to_interface();

	/**
	 * Binds socket to given port and ip address.
	 *
	 * @throw domain_error If the interface address is invalid
	 * @throw system_error If the socket could not be bound to given porn and address
	 */
	void bind_to_port_and_address();

	/**
	 * Disables loop-back which causes the messages not to be received in current node.
	 *
	 * @throw system_error If loop-back could not be disabled
	 */
	void disable_loopback();

	/**
	 * Prepares source address of to be sent messages.
	 *
	 * @throw domain_error If multicast address is invalid
	 */
	void make_send_address();

	/// Shows if messages should be sent to current node or not.
	const bool should_send_to_loopback;

	/// Source address of sent messages.
	sockaddr_in source_address;
};

}

#endif
