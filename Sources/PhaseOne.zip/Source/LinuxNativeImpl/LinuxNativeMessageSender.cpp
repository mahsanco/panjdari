#include "LinuxNativeMessageSender.h"

#include <cstring>
#include <stdexcept>
#include <string>
#include <system_error>

#include <arpa/inet.h>
#include <net/if.h>
#include <netdb.h>


using std::domain_error;
using std::string;
using std::system_error;

namespace gw
{

LinuxNativeMessageSender::LinuxNativeMessageSender(const std::string& group_address, const std::string& interface_name,
							   uint16_t port_number, bool should_send_to_loopback)
	: AbstractMessageSender(group_address, interface_name, port_number)
	, LinuxNativeMulticastBasic(interface_name, find_interface_ip(interface_name), port_number, group_address)
	, should_send_to_loopback(should_send_to_loopback)
{
	initialize();
}

bool LinuxNativeMessageSender::send(const uint8_t* message, size_t message_size) noexcept
{
	if (sendto(socket_descriptor, message, message_size, 0, reinterpret_cast<sockaddr*>(&source_address),
			   sizeof(source_address)) != static_cast<ssize_t>(message_size))
	{
		system_error_code = errno;
		return false;
	}

	return true;
}

bool LinuxNativeMessageSender::send(const string& message) noexcept
{
	return send(reinterpret_cast<const uint8_t*>(message.c_str()), message.length());
}

void LinuxNativeMessageSender::initialize()
{
	LinuxNativeMulticastBasic::initialize();

	make_send_address();
	if (!should_send_to_loopback) disable_loopback();
}

void LinuxNativeMessageSender::socket_bind()
{
	bind_to_interface();
	bind_to_port_and_address();
}

void LinuxNativeMessageSender::bind_to_interface()
{
	ifreq ifr;
	memset(&ifr, 0, sizeof(ifr));

	/*
	 * Dangerous usage:
	 * snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), interface_name);
	 */
	snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", AbstractMessageSender::interface_name.c_str());

	/*
	 * SO_BINDTODEVICE: binds socket to a particular device like 'eth0'. If the name is an empty string or the option
	 * length is zero the socket binding is removed.
	 */
	if (setsockopt(socket_descriptor, SOL_SOCKET, SO_BINDTODEVICE, reinterpret_cast<void*>(&ifr), sizeof(ifr)) < 0)
		throw system_error(errno, std::system_category(),
						   "Error in binding socket to interface name " + AbstractMessageSender::interface_name);
}

void LinuxNativeMessageSender::bind_to_port_and_address()
{
	/*
	 * Setting 'IP_MULTICAST_IF' socket option will do same for interface address binding, but 'bind' sets source port
	 * too, so we use it.
	 */

	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;

	if (inet_aton(interface_address.c_str(), &addr.sin_addr) == 0)  // 'inet_aton' used instead of 'inet_addr'
		// Returns '0' if address is invalid but errno is not set
		throw domain_error("Error in using interface address " + interface_address);

	addr.sin_port = htons(port);

	// 'addr' used instead of 'sockaddr_in'
	if (bind(socket_descriptor, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0)
		throw system_error(errno, std::system_category(),
						   "Error in binding sender socket to interface address " + interface_address + " and port " +
							   std::to_string(port));
}

void LinuxNativeMessageSender::disable_loopback()
{
	int value = 0;  // '0' to disable loop-back
	if (setsockopt(socket_descriptor, IPPROTO_IP, IP_MULTICAST_LOOP, &value, sizeof(value)) < 0)
		throw system_error(errno, std::system_category(), "Error in disabling socket loop-back");
}

void LinuxNativeMessageSender::make_send_address()
{
	memset(&source_address, 0, sizeof(source_address));
	source_address.sin_family = AF_INET;

	if (inet_aton(multicast_address.c_str(), &source_address.sin_addr) == 0)
		throw domain_error("Error in using multicast address " + multicast_address);

	source_address.sin_port = htons(port);
}

}
