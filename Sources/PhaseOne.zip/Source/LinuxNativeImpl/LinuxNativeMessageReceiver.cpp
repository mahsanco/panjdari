#include "LinuxNativeMessageReceiver.h"

#include <cstring>

#include <string>
#include <system_error>

#include <fcntl.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>

using std::string;
using std::system_error;
using std::make_pair;

namespace gw
{
LinuxNativeMessageReceiver::LinuxNativeMessageReceiver(const std::string& group_address, const std::string& interface_name,
						   uint16_t port_number, bool is_nonblock)
	: LinuxNativeMulticastBasic(interface_name, find_interface_ip(interface_name), port_number, group_address)
	, AbstractMessageReceiver(group_address, interface_name, port_number),
      is_nonblock(is_nonblock)
{
	initialize();
}

std::pair<bool, std::size_t> LinuxNativeMessageReceiver::receive(AbstractMessageReceiver::MutableBuffer& buffer) noexcept
{
	std::string sent_ip;
	const size_t message_capacity = buffer.size();
	uint8_t* const message = static_cast<uint8_t*>(buffer.data());

	if (message == nullptr && message_capacity > 0)
	{
		// Receiving could not be done, because message pointer is null but has capacity
		system_error_code = EFAULT;
		return make_pair(false, 0);
	}

	ssize_t bytes_received = 0;
	socklen_t sent_address_length = sizeof(source_address);
	if ((bytes_received = recvfrom(socket_descriptor, reinterpret_cast<void*>(message), message_capacity, MSG_TRUNC,
								   reinterpret_cast<sockaddr*>(&source_address), &sent_address_length)) < 0)
	{
		// The receive in non-block and there is no data on wire.
		if ((bytes_received == -1) && (errno == EAGAIN || errno == EWOULDBLOCK))
		{
			return make_pair(true, 0);
		}
		else  // Error occurred in receiving
		{
			system_error_code = errno;
			return make_pair(false, 0);
		}
	}

	// Now "bytes_received" is greater than zero
	if (static_cast<size_t>(bytes_received) > message_capacity)
	{  // Buffer capacity was not enough, message is truncated
		system_error_code = ENOBUFS;
		return make_pair(false, 0);
	}

	sent_ip = inet_ntoa(source_address.sin_addr);
	return make_pair(true, static_cast<size_t>(bytes_received));
}

void LinuxNativeMessageReceiver::make_nonblock()
{
	if (fcntl(socket_descriptor, F_SETFL, fcntl(socket_descriptor, F_GETFL) | O_NONBLOCK) < 0)
		throw system_error(errno, std::system_category(), "Error in making socket non-block");
}

void LinuxNativeMessageReceiver::make_blocking()
{
	if (fcntl(socket_descriptor, F_SETFL, fcntl(socket_descriptor, F_GETFL) & ~O_NONBLOCK) < 0)
		throw system_error(errno, std::system_category(), "Error in making socket blocking");
}

void LinuxNativeMessageReceiver::set_timeout(size_t timeout) const
{
	constexpr int MILLISECOND_TO_MICROSECOND = 1e3;
	constexpr int MILLISECOND_TO_SECOND = 1e3;
	timeval tv;
	tv.tv_sec = timeout / MILLISECOND_TO_SECOND;
	tv.tv_usec = (timeout % MILLISECOND_TO_SECOND) * MILLISECOND_TO_MICROSECOND;
	if (setsockopt(socket_descriptor, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(timeval)) < 0)
		throw system_error(errno, std::system_category(), "Error in setting timeout for socket descriptor");
}

void LinuxNativeMessageReceiver::initialize()
{
	LinuxNativeMulticastBasic::initialize();

	add_membership_with_interface();
	if (is_nonblock) make_nonblock();

	set_receive_buffer_size(DEFAULT_BUFFER_SIZE);
	set_minimum_bytes_to_receive(DEFAULT_MINIMUM_BYTES_TO_RECEIVE);
}

void LinuxNativeMessageReceiver::socket_bind() { bind_to_port(); }

void LinuxNativeMessageReceiver::bind_to_port()
{
	sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htons(INADDR_ANY);
	addr.sin_port = htons(port);

	if (bind(socket_descriptor, reinterpret_cast<sockaddr*>(&addr), sizeof(sockaddr_in)) < 0)
		throw system_error(errno, std::system_category(),
						   "Error in binding socket to port number " + std::to_string(port));
}

void LinuxNativeMessageReceiver::add_membership_with_interface()
{
	ip_mreq multicast_request;
	memset(&multicast_request, 0, sizeof(multicast_request));
	multicast_request.imr_multiaddr.s_addr = inet_addr(multicast_address.c_str());

	multicast_request.imr_interface.s_addr = inet_addr(interface_address.c_str());

	if (setsockopt(socket_descriptor, IPPROTO_IP, IP_ADD_MEMBERSHIP, static_cast<void*>(&multicast_request),
				   sizeof(multicast_request)) < 0)
		throw system_error(errno, std::system_category(),
						   "Error in requesting membership to interface address " + interface_address);
}

void LinuxNativeMessageReceiver::set_receive_buffer_size(size_t buffer_size)
{
	if (setsockopt(socket_descriptor, SOL_SOCKET, SO_RCVBUFFORCE, &buffer_size, sizeof(buffer_size)) < 0)
		throw system_error(errno, std::system_category(),
						   "Error in setting receive buffer size to " + std::to_string(buffer_size));
}

void LinuxNativeMessageReceiver::set_minimum_bytes_to_receive(size_t minimum_bytes_to_receive)
{
	if (setsockopt(socket_descriptor, SOL_SOCKET, SO_RCVLOWAT, &minimum_bytes_to_receive,
				   sizeof(minimum_bytes_to_receive)) < 0)
		throw system_error(errno, std::system_category(),
						   "Error in setting minimum bytes to receive to " + std::to_string(minimum_bytes_to_receive));
}

void LinuxNativeMessageReceiver::cleanup() noexcept
{
	// TODO: leave group
	LinuxNativeMulticastBasic::cleanup();
}

}  // namespace gw
