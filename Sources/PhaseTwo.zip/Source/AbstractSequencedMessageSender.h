#pragma once
#ifndef GW_ABSTRACT_SEQUENCED_MESSAGE_SENDER_H_
#define GW_ABSTRACT_SEQUENCED_MESSAGE_SENDER_H_

#include <string>

#include "AbstractMessageSender.h"

namespace gw
{

class AbstractSequencedMessageSender
{
public:
	explicit AbstractSequencedMessageSender(AbstractMessageSender* inner_sender)
	: inner_sender(inner_sender)
	{
	}

	virtual bool send(const std::string& message) noexcept = 0;

protected:
	AbstractMessageSender* inner_sender;
};

}

#endif
