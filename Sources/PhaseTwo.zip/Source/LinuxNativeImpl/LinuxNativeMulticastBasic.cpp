#include "LinuxNativeMulticastBasic.h"

#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <system_error>

#include <arpa/inet.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <unistd.h>

using std::cout;
using std::endl;
using std::string;
using std::system_error;

namespace gw
{

string LinuxNativeMulticastBasic::find_interface_ip(const string& interface_name)
{
	int socket_descriptor = socket(AF_INET, SOCK_DGRAM, 0);
	if (socket_descriptor < 0)
		throw system_error(errno, std::system_category(), "Error while creating socket in find_interface_ip()");

	ifreq ifreq_object;
	memset(&ifreq_object, 0, sizeof(ifreq_object));
	ifreq_object.ifr_addr.sa_family = AF_INET;
	strncpy(ifreq_object.ifr_name, interface_name.c_str(), IFNAMSIZ - 1);

	if (ioctl(socket_descriptor, SIOCGIFADDR, &ifreq_object) < 0)
		throw system_error(errno, std::system_category(),
						   "Error while getting interface address by its name in ioctl()");
	if (close(socket_descriptor) < 0)
		throw system_error(errno, std::system_category(), "Error while closing socket descriptor");
	return string(inet_ntoa((reinterpret_cast<sockaddr_in*>(&ifreq_object.ifr_addr))->sin_addr));
}

LinuxNativeMulticastBasic::LinuxNativeMulticastBasic(const string& interface_name, const string& interface_address, uint16_t port,
							   const string& multicast_address)
	: socket_descriptor(0),
	  interface_name(interface_name),
	  interface_address(interface_address),
	  port(port),
	  multicast_address(multicast_address),
	  system_error_code(0)
{
}

LinuxNativeMulticastBasic::~LinuxNativeMulticastBasic() noexcept { cleanup(); }

void LinuxNativeMulticastBasic::print_attributes() const noexcept
{
	cout << "Interface Name: " << interface_name << endl;
	cout << "Interface Address: " << interface_address << endl;
	cout << "Port: " << port << endl;
	cout << "Multicast Address: " << multicast_address << endl;
}

const string& LinuxNativeMulticastBasic::get_multicast_address() const noexcept { return multicast_address; }

int LinuxNativeMulticastBasic::get_error_code() const noexcept { return system_error_code; }

string LinuxNativeMulticastBasic::get_error_message() const
{
	// All occurred errors has a corresponding system error code.
	return string(strerror(system_error_code));
}

size_t LinuxNativeMulticastBasic::get_mtu() const
{
	const size_t size_including_terminating_null_byte = interface_name.size() + 1;

	if (IF_NAMESIZE < size_including_terminating_null_byte)
		throw std::invalid_argument("Invalid length of interface name: " + std::to_string(interface_name.size()));

	ifreq ifr;
	memset(&ifr, 0, sizeof(ifreq));
	ifr.ifr_addr.sa_family = AF_INET;

	strncpy(ifr.ifr_name, interface_name.c_str(), size_including_terminating_null_byte);

	if (!ioctl(socket_descriptor, SIOCGIFMTU, &ifr)) return ifr.ifr_mtu;

	throw system_error(errno, std::system_category(), "Error in getting mtu");
}

void LinuxNativeMulticastBasic::set_mtu(size_t value) const
{
	// Minumum value of MTU (Maximum Transfer Unit) for IPv4
	constexpr size_t MIN_MTU = 68;

	if (value < MIN_MTU) throw std::invalid_argument("Invalid mtu value: " + std::to_string(value));

	ifreq ifr;
	memset(&ifr, 0, sizeof(ifreq));
	ifr.ifr_addr.sa_family = AF_INET;
	ifr.ifr_mtu = value;

	const size_t size_including_terminating_null_byte = interface_name.size() + 1;
	strncpy(ifr.ifr_name, interface_name.c_str(), size_including_terminating_null_byte);

	if (ioctl(socket_descriptor, SIOCSIFMTU, &ifr))
		throw system_error(errno, std::system_category(), "Error in setting mtu");
}

int LinuxNativeMulticastBasic::get_socket_descriptor() const noexcept { return socket_descriptor; }

string LinuxNativeMulticastBasic::get_interface_address() const noexcept { return interface_address; }

void LinuxNativeMulticastBasic::initialize()
{
	create_udp_socket();
	make_reusable();
	socket_bind();
}

/*
 * Create socket technical comment:
 *	socket(int socket_family, int socket_type, int protocol)
 *		socket_family:
 *			AF_INET: IPv4 internet protocols
 *				Note: PF_INET is same as AF_INET
 *		socket_type:
 *			SOCK_STREAM: sequenced, reliable, two-way, connection-based byte stream -> TCP
 *			SOCK_DGRAM: connectionless, unreliable, messages of a fixed maximum length -> UDP
 *			SOCK_RAW: raw protocol network access -> RAW
 *		protocol: use 0 to indicate implemented protocol for used socket type within used socket family
 *
 *	This function uses AF_INET socket family and SOCKET_DGRAM socket type with 0 protocol number.
 */
void LinuxNativeMulticastBasic::create_udp_socket()
{
	if ((socket_descriptor = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		throw system_error(errno, std::system_category(), "Error while creating udp socket in create_udp_socket()");
}

/*
 * SO_REUSEADDR: indicate that rules used in validating addresses supplied in bind call should allow reuse of local
 * addresses.
 */
void LinuxNativeMulticastBasic::make_reusable()
{
	int value = 1;  // '1' to enable reusability
	if (setsockopt(socket_descriptor, SOL_SOCKET, SO_REUSEADDR, &value, sizeof(value)) < 0)
		throw system_error(errno, std::system_category(), "Error in making socket address reusable");
}

void LinuxNativeMulticastBasic::cleanup() noexcept
{
	if (socket_descriptor > 0) close(socket_descriptor);
}

}  // namespace gw
