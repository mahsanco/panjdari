#pragma once

#ifndef GW_LINUX_NATIVE_MESSAGE_RECEIVER_H_
#define GW_LINUX_NATIVE_MESSAGE_RECEIVER_H_

#include <string>
#include <limits>

#include <netinet/in.h>

#include "../AbstractMessageReceiver.h"
#include "LinuxNativeMulticastBasic.h"

namespace gw
{

/**
 * An interface to receive byte array messages on specified interface from an specified multicast address. It uses IPv4
 * multicast implementation.
 */
class LinuxNativeMessageReceiver : public AbstractMessageReceiver, public LinuxNativeMulticastBasic
{
public:
	/// Default buffer size which is 1GB
	static constexpr size_t DEFAULT_BUFFER_SIZE = 1000 * 1000 * 1000;

	/// Default minimum bytes to receive
	static constexpr size_t DEFAULT_MINIMUM_BYTES_TO_RECEIVE = 1;

	/**
	 * @see LinuxNativeMulticastBasic::LinuxNativeMulticastBasic()
	 *
	 * @param is_nonblock Specifies if receiver works in non-block mode or not
	 *
	 * @note Receiver will use primary ip address of specified network interface as destination ip address.
	 *
	 * @throw system_error @see LinuxNativeMulticastBasic::initialize()
	 */
	LinuxNativeMessageReceiver(const std::string& group_address, const std::string& interface_name,
	                           uint16_t port_number, bool is_nonblock = false);

	/// @see LinuxNativeMulticastBasic::LinuxNativeMulticastBasic()
	~LinuxNativeMessageReceiver() = default;

	/**
	 * Receives a message from specified multicast address.
	 *
	 * @param sent_ip Ip address of sender of received message, note that this value is correct if message has been
	 * 		received correctly
	 *
	 * @return True if receiving is done successfully, @c false otherwise
	 *
	 * @note If receive method returns false, occurred error message could be determined by calling 'get_error_message()
	 */
	// #negaresh_command ignore runtime/references
	std::pair<bool, std::size_t> receive(AbstractMessageReceiver::MutableBuffer& buffer,
	                                     std::string& sent_ip) noexcept;
	std::pair<bool, std::size_t> receive(AbstractMessageReceiver::MutableBuffer& buffer) noexcept override;

	/**
	 * Makes socket work in non-block mode.
	 *
	 * @throw system_error If kernel fails to set socket as non-block
	 */
	void make_nonblock();

	/**
	 * Makes socket work in blocking mode.
	 *
	 * @throw system_error If kernel fails to set socket as blocking
	 */
	void make_blocking();

	/*
	 * Sets Time out for socket_descriptor. Is used in blocking mode
	 *
	 * @param timeout Time out in milliseconds
	 *
	 * @throw std::system_error If "setsockopt" return an error
	 */
	void set_timeout(size_t timeout) const;

private:
	/// @see LinuxNativeMulticastBasic::initialize()
	void initialize();

	/// @see LinuxNativeMulticastBasic::socket_bind()
	void socket_bind() override;

	/**
	 * Binds socket to given port.
	 *
	 * @throw system_error If the socket could not be bound to given port
	 */
	void bind_to_port();

	/**
	 * Sends membership request.
	 *
	 * @throw system_error If membership request could not be sent
	 */
	void add_membership_with_interface();

	/**
	 * Sets size of receiving buffer. Small values may lead to message drop, while, large values may increase the delay.
	 *
	 * @param buffer_size Size of buffer in bytes
	 *
	 * @throw system_error If kernel fails to set the given size
	 */
	void set_receive_buffer_size(size_t buffer_size);

	/**
	 * Sets minimum bytes cause triggering receive operation. Small values may decrease both delay and performance,
	 * while, large values do vice versa as well.
	 *
	 * @param minimum_bytes_to_receive Minimum bytes to receive
	 *
	 * @throw system_error If kernel fails to set given value as low water mark
	 */
	void set_minimum_bytes_to_receive(size_t minimum_bytes_to_receive);

	/// @see LinuxNativeMulticastBasic::cleanup()
	void cleanup() noexcept override;

	/// Shows if receiver works in non-block mode or blocking mode.
	const bool is_nonblock;

	/// Source address of last message
	sockaddr_in source_address;
};

}

#endif
