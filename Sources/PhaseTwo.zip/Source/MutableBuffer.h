#pragma once
#ifndef GW_MUTABLE_BUFFER
#define GW_MUTABLE_BUFFER

#include <cstddef>
#include <array>

namespace gw
{

class MutableBuffer
{
public:
  /// Construct an empty buffer.
  MutableBuffer() noexcept
    : data_(0),
      size_(0)
  {
  }

  /// Construct a buffer to represent a given memory range.
  MutableBuffer(void* data, std::size_t size) noexcept
    : data_(data),
      size_(size)
  {
  }

  /// Get a pointer to the beginning of the memory range.
  void* data() const noexcept
  {
    return data_;
  }

  /// Get the size of the memory range.
  std::size_t size() const noexcept
  {
    return size_;
  }

  /// Move the start of the buffer by the specified number of bytes.
  MutableBuffer& operator+=(std::size_t n) noexcept
  {
    std::size_t offset = n < size_ ? n : size_;
    data_ = static_cast<char*>(data_) + offset;
    size_ -= offset;
    return *this;
  }

private:
  void* data_;
  std::size_t size_;
};

/// Create a new modifiable buffer that represents the given POD array.
/**
 * @returns A mutable_buffer value equivalent to:
 * @code mutable_buffer(
 *     data.data(),
 *     data.size() * sizeof(PodType)); @endcode
 */
template <typename PodType, std::size_t N>
inline MutableBuffer buffer(
    std::array<PodType, N>& data) noexcept
{
  return MutableBuffer(data.data(), data.size() * sizeof(PodType));
}


}

#endif
