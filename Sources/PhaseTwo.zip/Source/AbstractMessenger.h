#pragma once
#ifndef GW_ABSTRACT_MESSENGER_H_
#define GW_ABSTRACT_MESSENGER_H_

#include <string>

namespace gw
{

class AbstractMessenger
{
public:
	AbstractMessenger(const std::string& group_address, const std::string& interface_name, uint16_t port_number);

protected:
	const std::string& group_address;
	const std::string& interface_name;
	const uint16_t port_number;
};

}

#endif
