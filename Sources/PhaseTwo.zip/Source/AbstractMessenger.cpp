#include "AbstractMessenger.h"

namespace gw
{

AbstractMessenger::AbstractMessenger(const std::string& group_address, const std::string& interface_name, uint16_t port_number)
	: group_address(group_address)
	, interface_name(interface_name)
	, port_number(port_number)
{
}

}
