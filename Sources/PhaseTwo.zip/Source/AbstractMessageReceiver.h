#pragma once

#ifndef GW_ABSTRACT_MESSAGE_RECEIVER_H_
#define GW_ABSTRACT_MESSAGE_RECEIVER_H_

#include "AbstractMessenger.h"
#include "MutableBuffer.h"

namespace gw
{

class AbstractMessageReceiver : public AbstractMessenger
{
public:
	using AbstractMessenger::AbstractMessenger;

	typedef class MutableBuffer MutableBuffer;

	virtual std::pair<bool, std::size_t> receive(MutableBuffer& buffer) noexcept = 0;
};

}  // namespace gw

#endif
