#pragma once
#ifndef GW_ABSTRACT_SEQUENCED_MESSAGE_RECEIVER_H_
#define GW_ABSTRACT_SEQUENCED_MESSAGE_RECEIVER_H_

#include "MutableBuffer.h"
#include "AbstractMessageReceiver.h"

namespace gw
{

class AbstractSequencedMessageReceiver
{
public:
	typedef class MutableBuffer MutableBuffer;

	explicit AbstractSequencedMessageReceiver(AbstractMessageReceiver* inner_receiver)
	: inner_receiver(inner_receiver)
	{
	}

	virtual std::pair<bool, std::size_t> receive(MutableBuffer& buffer) noexcept = 0;

protected:
	AbstractMessageReceiver* inner_receiver;
};

}

#endif
